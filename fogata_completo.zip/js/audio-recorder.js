// audio-recorder.js básico
console.log('Audio Recorder cargado.');
