// app.js básico
console.log('App.js cargado.');
